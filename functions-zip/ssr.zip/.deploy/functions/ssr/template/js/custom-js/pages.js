import EcomSearch from '@ecomplus/search-engine'
document.getElementById('c-64f1dde62cd6b65959373aa4').href = '/agua-perfumada-premium-500';
document.getElementById('c-64f1c5712cd6b65959370481').href = '/home-spray-premium-60';
document.getElementById('c-64f1d7972cd6b65959372789').href = '/home-spray-premium-500';
document.getElementById('c-64f1df9b2cd6b65959373fbe').href = '/home-spray-premium-1';
document.getElementById('cd-64f1dde62cd6b65959373aa4').href = '/agua-perfumada-premium-500';
document.getElementById('cd-64f1c5712cd6b65959370481').href = '/home-spray-premium-60';
document.getElementById('cd-64f1d7972cd6b65959372789').href = '/home-spray-premium-500';
document.getElementById('cd-64f1df9b2cd6b65959373fbe').href = '/home-spray-premium-1';
